<?php

include ("function.php");
?>


<?php
require_once 'vendor/autoload.php';
if (isset($_POST["submit"])) {
  $receiver = $_POST["receiver"];
  $subject = $_POST["subject"];
  $msg = $_POST["message"];
  $messagebird = new MessageBird\Client('V9NJzguchxFSXB2GuMYqrfy6r');
  $message = new MessageBird\Objects\Message;
  $message->originator = '+94755167083';
  $message->recipients = [ $receiver ];
  $message->body = $msg;
  $response = $messagebird->messages->create($message);
  print_r(json_encode($response));
}

?>


<!DOCTYPE html>
<html>
  <head>
  <!-- <script src="script.js"></script> -->
  


  </head>
<body>

<h2>HTML Forms</h2>

<!-- <form onsubmit="sendEmail(); reset(); return false;"> -->
  <form onsubmit="sendMail(); reset(); return false;">
  <label for="fname">First name:</label><br>
  <input name="receiver" type="text" id="name" name="fname" value=""><br>
  <label for="lname">email:</label><br>
  <input name="subject" type="text" id="email" name="lname" value=""><br><br>
  <label for="lname">phone:</label><br>
  <input name="message" type="text" id="phone" name="lname" value=""><br><br>
  
  
  <button name="submit">send</button>
</form> 





<script src="https://smtpjs.com/v3/smtp.js">
</script>

<script>
 require("dotenv").config();

const nodemailer = require("nodemailer");

let transport = nodemailer.createTransport({
  host: "smtp.gmail.com",
  port: 465,
  secure: true,
  auth: {
    user: "mohameddilshath22@gmail.com",
    pass: "Dilu@14230",
  },
});

const mailOptions = {
  from: "mohameddilshath22@gmail.com", // Sender address
  to: document.getElementById("email"), // List of recipients
  subject: "Node Mailer", // Subject line
  text: document.getElementById("phone"), // Plain text body
};

transport.sendMail(mailOptions, function (err, info) {
  if (err) {
    console.log(err);
  } else {
    console.log(info);
  }
});

</script>

</body>

</html>

