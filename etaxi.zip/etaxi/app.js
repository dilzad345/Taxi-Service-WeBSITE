require("dotenv").config();

const nodemailer = require("nodemailer");

let transport = nodemailer.createTransport({
  host: "smtp.gmail.com",
  port: 465,
  secure: true,
  auth: {
    user: "azeem060697@gmail.com",
    pass: "epbey@1393",
  },
});

const mailOptions = {
  from: "azeem060697@gmail.com", // Sender address
  to: "mohameddilshath22@gmail.com", // List of recipients
  subject: "Node Mailer", // Subject line
  text: "Hello I amDilshat", // Plain text body
};

transport.sendMail(mailOptions, function (err, info) {
  if (err) {
    console.log(err);
  } else {
    console.log(info);
  }
});
