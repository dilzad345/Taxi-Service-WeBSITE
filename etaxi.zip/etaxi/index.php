<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>Taxi</title>

  <!-- Bootstrap -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
    integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link
    href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;700;900&family=Ubuntu:wght@300;400;500;700&display=swap"
    rel="stylesheet">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />

  <!-- Custom Style -->
  <link rel="stylesheet" href="css/styles.css">
</head>

<body>

  <section id="title">

    <div class="container-fluid">

      <!-- Nav Bar -->
      <nav class="navbar navbar-expand-lg navbar-dark">
        <a href="Index.php" class="navbar-brand" style="color: black;">City Taxi</a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01"
          aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a href="#footer" class="nav-link">Contact</a>
            </li>
            <li class="nav-item">
              <a href="#pricing" class="nav-link">Plan</a>
            </li>
            <li class="nav-item">
              <a href="#cta" class="nav-link">Download</a>
            </li>
            <li class="nav-item">
              <a href="dlogin.php" class="nav-link">Drivers</a>
            </li>
          </ul>
        </div>
      </nav>

      <!-- Title -->

      <div class="row">
        <div class="col-lg-6">
          <h1>Always the ride you want. Request a ride.</h1>
         <a href="Home.php"> <button type="button" class="download-btn btn btn-dark btn-lg"><i class=""></i> Login</button></a>
         <a href="signup.php"> <button type="button" class="download-btn btn btn-outline-light btn-lg"><i class=""></i>
            Signup</button></a>
        </div>

        <div class="col-lg-6">
          <img class="title-img" src="images/carTexi.jpg" alt="iphone-mockup">
        </div>
      </div>
    </div>
  </section>

  <!-- Features -->

  <section id="features">

    <div class="row">
      <div class="feature-box col-lg-4">
        <i class="icon fas fa-check fa-4x"></i>
        <h3>Rides on demand.</h3>
        <p>Request a ride at any time and on any day of the year.</p>
      </div>

      <div class="feature-box col-lg-4">
        <i class="icon fas fa-bullseye fa-4x"></i>
        <h3>An easy way to get around</h3>
        <p>Tap and let your driver take you where you want to go, worry-free.</p>
      </div>

      <div class="feature-box  col-lg-4">
        <i class="icon fas fa-heart fa-4x"></i>
        <h3>Budget-friendly options</h3>
        <p>Compare prices on every kind of ride, from daily commutes to special evenings out.</p>
      </div>
    </div>

  </section>

  <!-- Testimonials -->

  <section id="testimonials">

    <div id="testimonials-carousel" class="carousel slide" data-ride="carousel">

      <div class="carousel-inner">
        <div class="carousel-item active">
          <h2>There Are Definitly Answers Only The Cab Driver Can Give Us.</h2>
          <img class="testimonial-image" src="images/man-amg1.png" alt="dog-profile">
          <em>stephen sirard</em>
        </div>
        <div class="carousel-item">
          <h2 class="testimonial-text">Silence Sat In The Taxi, As Though A Stranger Had Got In.</h2>
          <img class="testimonial-image" src="images/e-texi1.png" alt="lady-profile">
          <em>Elizebeth Bowen</em>
        </div>
      </div>

      <a class="carousel-control-prev" href="#testimonials-carousel" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon"></span>
      </a>
      <a class="carousel-control-next" href="#testimonials-carousel" role="button" data-slide="next">
        <span class="carousel-control-next-icon"></span>
      </a>

    </div>

  </section>

  <!-- Press -->

  <section id="press">
    <img src="images/techcrunch.png" alt="tc-logo">
    <img src="images/tnw.png" alt="tnw-logo">
    <img src="images/bizinsider.png" alt="biz-insider-logo">
    <img src="images/mashable.png" alt="mashable-logo">

  </section>

  <!-- Pricing -->

  <section id="pricing">

    <h2>A plan for the needs of each trip</h2>
    <p>Simple and affordable price plans for your and your travel.</p>

    <div class="row">

      <div class="pricing-column col-lg-4 col-md-6">
        <div class="card">
          <div class="card-header">
            <h3>Ride</h3>
          </div>
    
          <div class="card-body">
            <h2>Rs.50 / Km</h2>
            <p>Will be parked in only one place.</p>
            <p>Your stops cannot be changed.</p>
            <p>There is separate charge for parking.</p>
            <button type="button" class="btn btn-lg btn-block btn-outline-dark">Start Up</button>
          </div>
        </div>
      </div>
      
      <div class="pricing-column col-lg-4 col-md-6">
        <div class="card">
          <div class="card-header">
            <h3>Rental</h3>
          </div>
    
          <div class="card-body">
            <h2>5000 / Day</h2>
            <p>As Many Stops As You Need In 1 Car.</p>
            <p>Change Your Stops On The Go.</p>
            <p>Don't Spend Time To Park.</p>
            <button type="button" class="btn btn-lg btn-block btn-dark">Start Up</button>
          </div>
        </div>
      </div>
      
      <div class="pricing-column col-lg-4">
        <div class="card">
          <div class="card-header">
            <h3>Intercity</h3>
          </div>
    
          <div class="card-body">
            <h2>1000 / Hour</h2>
            <p>For Outstation Trips.</p>
            <p>Convenient And affordable Rides.</p>
            <p>Available Anywhere, Anytime.</p>
            
            <button type="button" class="btn btn-lg btn-block btn-dark">Start Up</button>
          </div>
        </div>
      </div>
  
    </div>
   
  </section>

  <!-- Call to Action -->

  <section id="cta">

    <h3 class="cta-heading">Get in touch with your beautiful journey today through your mobile..</h3>
    <button type="button" class="download-btn btn btn-lg btn-dark"><i class="fab fa-apple"></i> Download</button>
    <button type="button" class="download-btn btn btn-lg btn-light"><i class="fab fa-google-play"></i>Download</button>

  </section>

  <!-- Footer -->

  <footer id="footer">

    <i class="social-icon fab fa-facebook-f"></i>
    <i class="social-icon fab fa-twitter"></i>
    <i class="social-icon fab fa-instagram"></i>
    <i class="social-icon fas fa-envelope"></i>

    <p>© Copyright 2021 E-Texi Pvt Ltd.</p>  

  </footer>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
    integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
  </script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
    integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"
    integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous">
  </script>
</body>

</html>