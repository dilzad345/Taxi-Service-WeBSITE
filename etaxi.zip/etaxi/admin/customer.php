<?php

include ("function.php");
?>



<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>Taxi</title>

  <!-- Bootstrap -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
    integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link
    href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;700;900&family=Ubuntu:wght@300;400;500;700&display=swap"
    rel="stylesheet">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />

  <!-- Custom Style -->
  <link rel="stylesheet" href="css/styles.css">
</head>

<style>
    #customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #FDFEFE;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #979A9A;
  color: white;
}
</style>

<body>

  <section id="title">

    <div class="container-fluid">

      <!-- Nav Bar -->
      <nav class="navbar navbar-expand-lg navbar-dark">
        <a href="dashboard.php" class="navbar-brand">City Taxi</a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01"
          aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a href="dashboard.php" class="nav-link">Dshboard</a>
            </li>
            <!-- <li class="nav-item">
              <a href="drivers.php" class="nav-link">Signup</a>
            </li> -->
            <!-- <li class="nav-item">
              <a href="#cta" class="nav-link">Download</a>
            </li> -->
          </ul>
        </div>
      </nav>

      
      <div>
          <h1 style="text-align: center; font-size:30px;">Customer Details</h1>
      </div>
      <!-- login -->
      <table id="customers">
  <tr>
    <th>ID</th>
    <th>Mail</th>
    <th>Number</th>
    <th>Password</th>
    <th>Responce</th>

    

  </tr>

  <?php 

$conn =  getDBconnection ();
$sql = "SELECT * FROM register";
$result = mysqli_query($conn , $sql);




                                if (mysqli_num_rows($result) > 0) {
                                    foreach ($result as $row) {


?>

  <tr>
    <td style="color:Black"><?php echo $row['id'] ?></td>
    <td style="color:Black"><?php echo $row['mail'] ?></td>
    <td style="color:Black"><?php echo $row['number'] ?></td>
    <td style="color:Black"><?php echo $row['password'] ?></td>
    
    
    <td>
                <form action="customer.php" method="post">
                  <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                  <button type="submit" name="" class="btn btn-success">Accept</button>
                  <a href="getAdminReserve.php?id=<?php echo $row['id'] ?>" class="btn btn-danger" >Disable</a>
                   </form>
            </td>
</tr>
<?php                            

                                    }
                                } else {
                                    echo "<script>alert('No news available')</script>";
                                }

?>

</table>

     
  </section>

  <!-- Features -->

  <section id="">

    

  </section>

  <!-- Press -->

 

  <!-- Pricing -->

  

  <!-- Footer -->

  <footer id="footer">

    <i class="social-icon fab fa-facebook-f"></i>
    <i class="social-icon fab fa-twitter"></i>
    <i class="social-icon fab fa-instagram"></i>
    <i class="social-icon fas fa-envelope"></i>

    <p>© Copyright 2021 E-Texi Pvt Ltd.</p>  

  </footer>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
    integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
  </script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
    integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"
    integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous">
  </script>
</body>

</html>