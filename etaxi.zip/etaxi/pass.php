<?php
// include ("function.php");
?>

<?php 

// if (isset($_POST['Driaccept'])) {

//     $id = $_POST['a_id'];
//     $conn = getDBconnection();
//     $sql = "Select * FROM  reserve WHERE id='$id'";
//     $result = mysqli_query($conn , $sql);
//     mysqli_num_rows($result);
//     foreach ($result as $row) {
//         $place1 = $row['place1'];
//         $place2=  $row['place2'];
//         // echo $place2;
//         $sql = "INSERT INTO driverAccept (id,place1,place2) VALUES ('$id','$place1','$place2')";

//         if (mysqli_query($conn, $sql)) {
//             echo "<script>alert('Insert Success')</script>";
//         }
//         else {
//             echo "<script>alert('Somethink Went Wrong')</script>";
//         }
//     }}
 
?>

